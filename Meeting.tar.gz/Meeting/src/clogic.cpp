#include "clogic.h"

void CLogic::setNetPackMap()
{
    NetPackMap(_DEF_PACK_REGISTER_RQ)    = &CLogic::RegisterRq;
    NetPackMap(_DEF_PACK_LOGIN_RQ)       = &CLogic::LoginRq;
    NetPackMap(_DEF_PACK_CREATE_ROOM_RQ) = &CLogic::CreateRoomRq;
    NetPackMap(_DEF_PACK_JOIN_ROOM_RQ)   = &CLogic::JoinRoomRq;
    NetPackMap(_DEF_PACK_LEAVE_ROOM_RQ)  = &CLogic::LeaveRoomRq;
    NetPackMap(_DEF_PACK_AUDIO_FRAME_RQ) = &CLogic::AudioFrameRq;
    NetPackMap(_DEF_PACK_VIDEO_FRAME_RQ) = &CLogic::VideoFrameRq;
}

#define _DEF_COUT_FUNC_    cout << "clientfd:"<< clientfd << __func__ << endl;

//注册
void CLogic::RegisterRq(sock_fd clientfd,char* szbuf,int nlen)
{
    //cout << "clientfd:"<< clientfd << __func__ << endl;
    _DEF_COUT_FUNC_;
    //拆包
    STRU_REGISTER_RQ* rq = (STRU_REGISTER_RQ*)szbuf;
    STRU_REGISTER_RS rs;
    //查数据库　用户名　手机号　是否重复
    char sqlstr[1000] = "";
    sprintf(sqlstr, "select u_tel from t_user where u_tel = '%s';", rq->tel);
    list<string> lstRes;
    bool res = m_sql->SelectMysql( sqlstr, 1, lstRes );
    if( !res )
        std::cout<< "select fail" << sqlstr << endl;
    if( lstRes.size() != 0 ){
        //存在　返回
        rs.result = tel_is_exist;
    }else{//手机号不存在
        sprintf(sqlstr, "select u_tel from t_user where u_name = '%s';", rq->name);
        lstRes.clear();
        res = m_sql->SelectMysql( sqlstr, 1, lstRes );
        if( !res )
            std::cout<< "select fail" << sqlstr << endl;
        if( lstRes.size() != 0){
            //昵称存在　返回
            rs.result = name_is_exist;
        }else{
            //昵称不存在
            rs.result = register_success;
            //写入数据库
            sprintf(sqlstr, "insert into t_user(u_tel, u_password, u_name) values ('%s', '%s', '%s');",
                    rq->tel, rq->password, rq->name);
            res = m_sql->UpdataMysql( sqlstr );
            if( !res )
                std::cout<< "updata fail" << sqlstr << endl;
        }
    }
    //写回复
    SendData( clientfd, (char*)&rs, sizeof(rs) );
}

//登录
void CLogic::LoginRq(sock_fd clientfd ,char* szbuf,int nlen)
{
    //cout << "clientfd:"<< clientfd << __func__ << endl;
    _DEF_COUT_FUNC_
            STRU_LOGIN_RQ * rq = (STRU_LOGIN_RQ*)szbuf;
    STRU_LOGIN_RS rs;
    //查询手机号
    char sqlbuf[1000] = "";
    list<string> lstRes;
    sprintf( sqlbuf, "select u_password, u_id, u_name from t_user where u_tel = '%s';", rq->tel );
    bool res = m_sql->SelectMysql( sqlbuf, 3, lstRes );
    if( !res )
        std::cout<< "select fail" << sqlbuf << endl;

    if( lstRes.size() == 0 ){
        //用户不存在　返回
        rs.result = tel_not_exist;
    }else{
        //存在　password 判断是否一致
        string strPassword = lstRes.front();
        lstRes.pop_front();
        if( strcmp( rq->password, strPassword.c_str() ) != 0){
            //不一致　返回密码错误
            rs.result = password_error;
        }else{
            //一致　返回
            rs.result = login_success;
            int id = atoi(lstRes.front().c_str());
            lstRes.pop_front();
            rs.userid = id;
            string strName = lstRes.front();
            lstRes.pop_front();
            strcpy( rs.name, strName.c_str() );
            //保存用户身份
            //创建用户身份结构map
            //先看在不在　在考虑下线
            UserInfo * info = nullptr;
            if( !m_mapIDToUserInfo.find(id, info) ){
                //查不到　创建
                info = new UserInfo;
            }else{
                //todo: 下线
            }
            info->name = strName;
            info->clientfd = clientfd;
            info->userid = id;
            //写入map
            m_mapIDToUserInfo.insert( id, info );
        }
    }

    SendData( clientfd , (char*)&rs , sizeof rs );
}

void CLogic::CreateRoomRq(sock_fd clientfd, char *szbuf, int nlen)
{
    _DEF_COUT_FUNC_;
    //拆包
    STRU_CRAETE_ROOM_RQ* rq= (STRU_CRAETE_ROOM_RQ*)szbuf;
    //创建房间号　需要存储房间号和用户信息　map roomid--＞list<int>
    int roomid = 0;
    do{
        //        //保证8位
        //        roomid = random()%9; //随机出1-9
        //        roomid *= 10000000;
        //        roomid += random() % 10000000;
        //随机１-８位
        roomid = random()%99999999 + 1;
        //去重　查询分享码是否已存在
        if( m_mapRoomidToUserlist.IsExist(roomid)){
            roomid = 0;
        }
    }while(roomid == 0);
    list<int> lst;
    lst.push_back(rq->userid);
    m_mapRoomidToUserlist.insert(roomid, lst);
    //回复
    STRU_CRAETE_ROOM_RS rs;
    rs.roomid = roomid;
    rs.result = create_room_success;
    //  cout<<roomid<<endl;
    SendData( clientfd , (char*)&rs , sizeof rs );
}

void CLogic::JoinRoomRq(sock_fd clientfd, char *szbuf, int nlen)
{
    _DEF_COUT_FUNC_
            //拆包
            STRU_JOIN_ROOM_RQ * rq = (STRU_JOIN_ROOM_RQ*)szbuf;
    STRU_JOIN_ROOM_RS rs;
    rs.roomid = rq->roomid;

    STRU_ROOM_MEMBER_RQ joinerrq; //新加入用户
    joinerrq.userid = rq->userid;
    UserInfo* joinerinfo = nullptr;
    m_mapIDToUserInfo.find(rq->userid, joinerinfo);
    strcpy(joinerrq.name, joinerinfo->name.c_str());

    //判断是否存在　map
    list<int> userlist;
    if( !m_mapRoomidToUserlist.find(rq->roomid, userlist)){
        //不存在返回
        rs.result = join_room_fail;
        SendData( clientfd , (char*)&rs , sizeof( rs ));
        return;
    }
    //存在　返回成功
    rs.result = join_room_success;
    SendData( clientfd , (char*)&rs , sizeof(rs) );

    //先添加自己到控件上
    SendData( clientfd , (char*)&joinerrq , sizeof(joinerrq) );
    list<int>::iterator ite = userlist.begin();
    while(ite != userlist.end()){
        // 查房间内成员信息
        int Memid = *ite;

        STRU_ROOM_MEMBER_RQ memrq;
        UserInfo* info = nullptr;
        if(!m_mapIDToUserInfo.find(Memid, info)){
            continue;
        }
        memrq.userid = Memid;
        strcpy(memrq.name, info->name.c_str());
        //给新加入用户发送成员信息
        SendData(clientfd, (char*)&memrq, sizeof(memrq));
        //给每个成员发送加入人的信息
        SendData(info->clientfd, (char*)&joinerrq, sizeof(joinerrq));

        ite++;
    }
    //加入新成员
    userlist.push_back(rq->userid);
    /* m_mapRoomidToUserlist.erase(rq->roomid);  //覆盖　可以不用     */
    m_mapRoomidToUserlist.insert(rq->roomid, userlist);
}

void CLogic::LeaveRoomRq(sock_fd clientfd, char *szbuf, int nlen)
{
    _DEF_COUT_FUNC_
            //拆包
            STRU_LEAVE_ROOM_RQ* rq = (STRU_LEAVE_ROOM_RQ*) szbuf;
    //找到会议号　和　对应的list
    list<int> lst;
    if( !m_mapRoomidToUserlist.find(rq->roomid, lst) )  return;

    //遍历每个用户
    for( list<int>::iterator ite = lst.begin(); ite!= lst.end(); ){ //注意不要＋＋　因为有删除的结点
        //判断是不是自己，从会议室中删除自己
        if(rq->userid == *ite){
            ite = lst.erase(ite);
        }else{
            //判断在线转发
            UserInfo* info;
            if(m_mapIDToUserInfo.find(*ite, info)){
                SendData(info->clientfd, szbuf, nlen);
            }
            ++ite;
        }
    }
    if(lst.size() == 0){
        m_mapRoomidToUserlist.erase(rq->roomid);
        return;
    }
    //更新房间列表
    m_mapRoomidToUserlist.insert(rq->roomid, lst);
}

//    PackType type;
//    int userid;
//    int roomid;
//    int min;
//    int sec;
//    int msec;
//    QByteArray audioFrame;  //可变长度　使用柔性数组

void CLogic::AudioFrameRq(sock_fd clientfd, char *szbuf, int nlen)
{
    _DEF_COUT_FUNC_;
    //没有结构体的拆包 用临时指针读取
    char* tmp = szbuf;
    tmp += sizeof (int);//跳过类型
    int myid = *(int*)tmp;   //　获取房间号
    tmp += sizeof (int);//跳过用户id

    int roomid = *(int*)tmp;   //　获取房间号
    //获取成员列表
    list<int> lst;
    if( !m_mapRoomidToUserlist.find(roomid, lst))   return;
    //转发
    for( list<int>::iterator ite = lst.begin(); ite != lst.end(); ite++){
        int userid = *ite;
        if(myid == userid)  continue; //跳过自己
        UserInfo* info ;
        if(m_mapIDToUserInfo.find(userid, info))
            SendData(info->clientfd, szbuf, nlen);
    }
}

void CLogic::VideoFrameRq(sock_fd clientfd, char *szbuf, int nlen)
{
    _DEF_COUT_FUNC_
    //没有结构体的拆包 用临时指针读取
    char* tmp = szbuf;
    tmp += sizeof (int);//跳过类型
    int myid = *(int*)tmp;   //　获取用户id
    tmp += sizeof (int);
    int roomid = *(int*)tmp;   //　获取房间号
    //获取成员列表
    list<int> lst;
    if( !m_mapRoomidToUserlist.find(roomid, lst))   return;
    //转发
    for( list<int>::iterator ite = lst.begin(); ite != lst.end(); ite++){
        int userid = *ite;
        if(myid == userid)  continue; //跳过自己
        UserInfo* info ;
        if(m_mapIDToUserInfo.find(userid, info))
            SendData(info->clientfd, szbuf, nlen);
    }
}
